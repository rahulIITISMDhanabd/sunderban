"""
Simple HTTP Server for Sundarban Web App
This script creates a local web server to serve the web application.
"""

import http.server
import socketserver
import webbrowser
import os
import sys

def start_server(port=8000):
    """
    Start a simple HTTP server on the specified port
    """
    
    # Change to the directory containing the web files
    web_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(web_dir)
    
    # Create the server
    Handler = http.server.SimpleHTTPRequestHandler
    
    try:
        with socketserver.TCPServer(("", port), Handler) as httpd:
            print(f"Sundarban Web App Server")
            print(f"=" * 40)
            print(f"Server started at: http://localhost:{port}")
            print(f"Serving files from: {web_dir}")
            print(f"")
            print(f"To access the application:")
            print(f"1. Open your web browser")
            print(f"2. Go to: http://localhost:{port}")
            print(f"")
            print(f"Press Ctrl+C to stop the server")
            print(f"=" * 40)
            
            # Try to open the browser automatically
            try:
                webbrowser.open(f'http://localhost:{port}')
                print(f"Browser opened automatically")
            except:
                print(f"Could not open browser automatically")
            
            print(f"")
            
            # Start serving
            httpd.serve_forever()
            
    except KeyboardInterrupt:
        print(f"\nServer stopped by user")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"Error: Port {port} is already in use")
            print(f"Try a different port: python server.py --port 8001")
        else:
            print(f"Error starting server: {e}")

def main():
    """
    Main function to handle command line arguments
    """
    port = 8000
    
    # Check for port argument
    if len(sys.argv) > 1:
        if sys.argv[1] == '--port' and len(sys.argv) > 2:
            try:
                port = int(sys.argv[2])
            except ValueError:
                print("Invalid port number. Using default port 8000.")
        elif sys.argv[1] in ['-h', '--help']:
            print("Sundarban Web App Server")
            print("Usage: python server.py [--port PORT]")
            print("Default port: 8000")
            return
    
    start_server(port)

if __name__ == "__main__":
    main()
